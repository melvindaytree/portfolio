$(document).ready(function(){
    $('.carousel').carousel({
      interval: 5000
    })
  });    
