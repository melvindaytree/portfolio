Page Scroll Effects
=========

Introducing a mini-library of experimental page scroll effects. All animations have been created using [Velocity.js](http://julian.com/research/velocity/).

[Article on CodyHouse](http://codyhouse.co/gem/page-scroll-effects/)

[Demo](http://codyhouse.co/demo/page-scroll-effects/scaledown.html)
 
[Terms](http://codyhouse.co/terms/)
